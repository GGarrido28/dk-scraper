from .scraper import ContestsScraper

__all__ = ["ContestsScraper"]
