from .scraper import PlayerSalaryScraper

__all__ = ["PlayerSalaryScraper"]
