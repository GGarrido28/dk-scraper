from .scraper import GameTypesScraper

__all__ = ["GameTypesScraper"]
